/********************************************************************/
/* Copyright (C) SSE-USTC, 2012-2013                                */
/*                                                                  */
/*  FILE NAME             :  linktabe.c                             */
/*  PRINCIPAL AUTHOR      :  Wangqun                                */
/*  SUBSYSTEM NAME        :  test                                   */
/*  MODULE NAME           :  test                                   */
/*  LANGUAGE              :  C                                      */
/*  TARGET ENVIRONMENT    :  ANY                                    */
/*  DATE OF FIRST RELEASE :  2012/09/23                             */
/*  DESCRIPTION           :  interface of test                      */
/********************************************************************/

/*
 * Revision log:
 *
 * Created by Wangqun,2012/09/23
 * Provide right Callback interface by Mengning,2012/09/17
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Menu.h"
#define CMD_MAX_LEN 1000

int results[10] = {1,1,1,1,1,1,1,1,1,1};
char info[10][100];
/*
 *start
 */
int main()
{
    int k = 0;
    tMenuNode *head = CreateMenu();
    if(head == NULL)
    {
        strcpy(info[k],"TC1 fail");
        results[k] = 0;
        k++;
    }
    
    tMenuNode *node = (tMenuNode *)malloc(sizeof(tMenuNode));
   
    if(AddMenuNode(node ,"help","help_cmd") == 3)
    {
        strcpy(info[k],"TC2 success");
        results[k] = 1;
        k++;
    }
    if(AddMenuNode(head ,"","help_cmd") == 1)
    {
        strcpy(info[k],"TC3 fail");
        results[k] = 0;
        k++;
    }
    if(AddMenuNode(head ,"help","") == 2)
    {
        strcpy(info[k],"TC4 fail");
        results[k] = 0;
        k++;
    }
    if(AddMenuNode(head ,"help","hh") == 0)
    {
        strcpy(info[k],"TC5 fail");
        results[k] = 0;
        k++;
    }

    if(DeleteMenuCmd(head,"test") == 0)
    {
        strcpy(info[k],"TC6 fail");
        results[k] = 0;
        k++;
    }
    
    if(DeleteMenuCmd(node, "test_1") == 2)
    {
       strcpy(info[k],"TC7 success");
       results[k] = 1;
       k++;
    }
    if(DeleteMenuCmd(node, "") == 1)
    {
       strcpy(info[k],"TC8 fail");
       results[k] = 0;
       k++;
    }
    int i = 0;
    for(i = 0; i < 10; i++)
    {
        if(results[i] == 0)
        {
            printf("%s\n",info[i]);
        }
    }
}
