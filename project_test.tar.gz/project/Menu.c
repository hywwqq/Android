/********************************************************************/
/* Copyright (C) SSE-USTC, 2012-2013                                */
/*                                                                  */
/*  FILE NAME             :  linktabe.c                             */
/*  PRINCIPAL AUTHOR      :  Wangqun                                */
/*  SUBSYSTEM NAME        :  LinkTable                              */
/*  MODULE NAME           :  LinkTable                              */
/*  LANGUAGE              :  C                                      */
/*  TARGET ENVIRONMENT    :  ANY                                    */
/*  DATE OF FIRST RELEASE :  2012/09/23                             */
/*  DESCRIPTION           :  interface of menu.c                    */
/********************************************************************/

/*
 * Revision log:
 *
 * Created by Wangqun,2012/09/23
 * Provide right Callback interface by Mengning,2012/09/17
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Menu.h"
#define CMD_MAX_LEN 1000
/*
 *create a menu
 */
tMenuNode *CreateMenu()
{
    return NULL;
}

/*
 *add a menu node
 */
int  AddMenuNode(tMenuNode *pMenuHead ,char *pCmd, char *pDesc)
{
    if(strlen(pCmd) == 0)
        return 1;
    if(strlen(pDesc) == 0)
        return 2;
    if(pMenuHead == NULL)
        return 0;
    return 3; 
}

/*
 *show all menu node
 */
void ShowAllCmd(tMenuNode *pMenuHead)
{
}

/*
 *delete a menu node
 */
int DeleteMenuCmd(tMenuNode *pMenuHead,char *pCmd)
{
    if(pMenuHead == NULL)
        return 0;
    if(strlen(pCmd) == 0)
        return 1;
    return 2; 
}

/*
 *check if a menu node is exist
 */
int CheckCmd(tMenuNode *pMenuHead,char *pCmd)
{
}

/*
 *find a menu node 
 */
tMenuNode *FindMenuCmd(tMenuNode *pMenuHead,char *pCmd)
{
}
void  MenuStart(tMenuNode *pMenuHead)
{
    printf("Menu Start: \n");
    while(1)
    {
        char cmd[CMD_MAX_LEN];
        printf("Input a cmd > ");
        scanf("%s", cmd);
        tMenuNode *p = FindMenuCmd(pMenuHead, cmd);
        if(p == NULL)
        {
            printf("This is a wrong cmd!\n");
            continue;
        }
        printf("%s - %s\n", p->cmd, p->desc);
        if (!strcmp(p->cmd,"help"))
        {
            ShowAllCmd(pMenuHead);
        }
        if (!strcmp(p->cmd,"quit"))
        {
            exit(0);
        }
    }  
}
