/********************************************************************/
/* Copyright (C) SSE-USTC, 2012-2013                                */
/*                                                                  */
/*  FILE NAME             :  linktabe.c                             */
/*  PRINCIPAL AUTHOR      :  Wangqun                                */
/*  SUBSYSTEM NAME        :  menu                                   */
/*  MODULE NAME           :  menu                                   */
/*  LANGUAGE              :  C                                      */
/*  TARGET ENVIRONMENT    :  ANY                                    */
/*  DATE OF FIRST RELEASE :  2012/09/23                             */
/*  DESCRIPTION           :  interface of menu.h                    */
/********************************************************************/

/*
 * Revision log:
 *
 * Created by Wangqun,2012/09/23
 * Provide right Callback interface by Mengning,2012/09/17
 *
 */

#include <stdio.h>
#include "Link.h"

/*
 *type
 */
typedef struct MenuNode
{
    tLinkTableNode * pNext;
    char   cmd[1024];
    char   desc[1024];
} tMenuNode;

/*
 *create a menu
 */
tMenuNode * CreateMenu();

/*
 *add a menu node
 */
int  AddMenuNode(tMenuNode *pMenuHead ,char *pCmd, char *pDesc);

/*
 *delete a menu node
 */
int DeleteMenuCmd(tMenuNode *pMenuHead,char *pCmd);

/*
 *check if a menu node is exist
 */
int CheckCmd(tMenuNode *pMenuHead,char *pCmd);

/*
 *show all menu node
 */
void ShowAllCmd(tMenuNode *pMenuHead);

/*
 *find a menu node 
 */
tMenuNode *FindMenuCmd(tMenuNode *pMenuHead,char *pCmd);

/*
 *start menu 
 */
void  MenuStart(tMenuNode *pMenuHead);
