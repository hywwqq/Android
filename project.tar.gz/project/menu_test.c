/********************************************************************/
/* Copyright (C) SSE-USTC, 2012-2013                                */
/*                                                                  */
/*  FILE NAME             :  linktabe.c                             */
/*  PRINCIPAL AUTHOR      :  Wangqun                                */
/*  SUBSYSTEM NAME        :  test                                   */
/*  MODULE NAME           :  test                                   */
/*  LANGUAGE              :  C                                      */
/*  TARGET ENVIRONMENT    :  ANY                                    */
/*  DATE OF FIRST RELEASE :  2012/09/23                             */
/*  DESCRIPTION           :  interface of test                      */
/********************************************************************/

/*
 * Revision log:
 *
 * Created by Wangqun,2012/09/23
 * Provide right Callback interface by Mengning,2012/09/17
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Menu.h"
#define CMD_MAX_LEN 1000

/*
 *init node to menu
 */
void init(tMenuNode *phead)
{
    tMenuNode *node = (tMenuNode *)malloc(sizeof(tMenuNode));
    node->cmd = "help";
    node->desc = "help list";
    if(AddMenuNode(phead, node))
    {
        printf("%s cmd has been insert\n",node->cmd);
    }

    node = (tMenuNode *)malloc(sizeof(tMenuNode));
    node->cmd = "version";
    node->desc = "version 1.0";
    if(AddMenuNode(phead, node))
    {
        printf("%s cmd has been insert\n",node->cmd);
    }

    node = (tMenuNode *)malloc(sizeof(tMenuNode));
    node->cmd = "quit";
    node->desc = "The menu will be exit";
    if(AddMenuNode(phead, node))
    {
        printf("%s cmd has been insert\n",node->cmd);
    }

    node = (tMenuNode *)malloc(sizeof(tMenuNode));
    node->cmd = "test";
    node->desc = "This is test menu";
    if(AddMenuNode(phead, node))
    {
        printf("%s cmd has been insert\n",node->cmd);
    }
}

/*
 *check if some node is exist 
 */
void Check(tMenuNode *phead)
{
    if(CheckCmd(phead,"help"))
    {
        printf("help exist\n");
    }
}

/*
 *input cmd
 */
void InputCmd(tMenuNode *phead)
{
    while(1)
    {
        char cmd[CMD_MAX_LEN];
        printf("Input a cmd > ");
        scanf("%s", cmd);
        tMenuNode *p = FindMenuCmd(phead, cmd);
        if(p == NULL)
        {
            printf("This is a wrong cmd!\n");
            continue;
        }
        printf("%s - %s\n", p->cmd, p->desc);
        if (!strcmp(p->cmd,"help"))
        {
            ShowAllCmd(phead);
        }
        if (!strcmp(p->cmd,"quit"))
        {
            exit(0);
        }
    }  
    
}

/*
 *start
 */
int main()
{
    tMenuNode *head = CreateMenu();
    if(head != NULL)
    {
        printf("The Menu Has Been Create\n");
    }
    init(head); 
    Check(head);
    InputCmd(head);
}