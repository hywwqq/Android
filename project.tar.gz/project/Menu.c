/********************************************************************/
/* Copyright (C) SSE-USTC, 2012-2013                                */
/*                                                                  */
/*  FILE NAME             :  linktabe.c                             */
/*  PRINCIPAL AUTHOR      :  Wangqun                                */
/*  SUBSYSTEM NAME        :  LinkTable                              */
/*  MODULE NAME           :  LinkTable                              */
/*  LANGUAGE              :  C                                      */
/*  TARGET ENVIRONMENT    :  ANY                                    */
/*  DATE OF FIRST RELEASE :  2012/09/23                             */
/*  DESCRIPTION           :  interface of menu.c                    */
/********************************************************************/

/*
 * Revision log:
 *
 * Created by Wangqun,2012/09/23
 * Provide right Callback interface by Mengning,2012/09/17
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Menu.h"

/*
 *create a menu
 */
tMenuNode *CreateMenu()
{
    tMenuNode *head = (tMenuNode *)malloc(sizeof(tMenuNode));
    if(head == NULL)
    {
        return NULL;
    }
    return head;
}

/*
 *add a menu node
 */
int AddMenuNode(tMenuNode *pMenuHead,tMenuNode *pNode)
{
    if(AddLinkTableNode((tLinkTable *)pMenuHead,(tLinkTableNode *)pNode))
        return TRUE;
    else
        return FALSE;
}

/*
 *show all menu node
 */
void ShowAllCmd(tMenuNode *pMenuHead)
{
    tMenuNode *pNode = (tMenuNode*)GetLinkTableHead((tLinkTable *)pMenuHead);
    while(pNode != NULL)
    {
        printf("%s - %s\n", pNode->cmd, pNode->desc);
        pNode = (tMenuNode*)GetNextLinkTableNode((tLinkTable *)pMenuHead,(tLinkTableNode *)pNode);
    }
}

/*
 *delete a menu node
 */
int DeleteMenuCmd(tMenuNode *pMenuHead,char *pCmd)
{
    tMenuNode * pNode = (tMenuNode*)GetLinkTableHead((tLinkTable *)pMenuHead);
    while(pNode != NULL)
    {
        if(!strcmp(pNode->cmd, pCmd))
        {
            if(DelLinkTableNode((tLinkTable *)pMenuHead,(tLinkTableNode *)pNode))
            {
                return TRUE;
            }
            else
            {
                return FALSE;
            }
        }
        pNode = (tMenuNode*)GetNextLinkTableNode((tLinkTable *)pMenuHead,(tLinkTableNode *)pNode);
    }
    return FALSE;
}

/*
 *check if a menu node is exist
 */
int CheckCmd(tMenuNode *pMenuHead,char *pCmd)
{
    tMenuNode *pNode = (tMenuNode*)GetLinkTableHead((tLinkTable *)pMenuHead);
    while(pNode != NULL)
    {
        if(!strcmp(pNode->cmd, pCmd))
        {
            return TRUE;
        }
        pNode = (tMenuNode*)GetNextLinkTableNode((tLinkTable *)pMenuHead,(tLinkTableNode *)pNode);
    }
    return FALSE;
}

/*
 *find a menu node 
 */
tMenuNode *FindMenuCmd(tMenuNode *pMenuHead,char *pCmd)
{
    tMenuNode * pNode = (tMenuNode*)GetLinkTableHead((tLinkTable *)pMenuHead);
    while(pNode != NULL)
    {
        if(!strcmp(pNode->cmd, pCmd))
        {
            return pNode;
        }
        pNode = (tMenuNode*)GetNextLinkTableNode((tLinkTable *)pMenuHead,(tLinkTableNode *)pNode);
    }
    return NULL;
}